import { BrowserBroker, BridgeError, DEFAULT_PORT, VERSION, assertJson } from './connector.mjs';
import { lstat, readFile } from 'node:fs/promises';
import { resolve, relative, extname, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const WEB_ROOT = resolve(dirname(fileURLToPath(import.meta.url)), 'web');
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8', '.dedalo': 'application/json; charset=utf-8', '.ifc': 'application/x-step', '.svg': 'image/svg+xml', '.png': 'image/png',
  '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.ico': 'image/x-icon', '.md': 'text/plain; charset=utf-8', '.txt': 'text/plain; charset=utf-8', '.wasm': 'application/wasm', '.pdf': 'application/pdf' };
async function serveStatic(req, res, headers, root) {
  const raw = String(req.url || '').split('?')[0];
  if (raw !== '/dedalo' && !raw.startsWith('/dedalo/')) return false;
  let pathname; try { pathname = decodeURIComponent(raw); } catch { throw new BridgeError('D_PATH', 'Ruta no válida.', 400); }
  if (/[\\\0-\x1f]/.test(pathname)) throw new BridgeError('D_PATH', 'Ruta no válida.', 403);
  const parts = pathname.split('/').filter(Boolean);
  if (parts.some(p => p === '..' || p.startsWith('.')) || parts[0] !== 'dedalo') throw new BridgeError('D_PATH', 'Ruta no permitida.', 403);
  const segments = parts.length === 1 || pathname.endsWith('/') ? [...parts, 'index.html'] : parts;
  let candidate = resolve(root);
  try {
    if ((await lstat(candidate)).isSymbolicLink()) throw new BridgeError('D_PATH', 'Enlaces no permitidos.', 403);
    for (const segment of segments) { candidate = resolve(candidate, segment); if ((await lstat(candidate)).isSymbolicLink()) throw new BridgeError('D_PATH', 'Enlaces no permitidos.', 403); }
    const rel = relative(resolve(root), candidate); if (rel.startsWith('..') || !rel) throw new BridgeError('D_PATH', 'Ruta no permitida.', 403);
    const stat = await lstat(candidate), mime = MIME[extname(candidate).toLowerCase()];
    if (!stat.isFile() || !mime || stat.size > 20 * 1024 * 1024) throw new BridgeError('D_FILE', 'Archivo no permitido.', 404);
    const body = await readFile(candidate);
    res.writeHead(200, { ...headers, 'Content-Type': mime,
      'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob: https://tile.openstreetmap.org https://www.ign.es; font-src 'self' data:; connect-src 'self' http://127.0.0.1:*; worker-src 'self' blob:; object-src 'none'; base-uri 'self'; frame-ancestors 'none'",
      'X-Frame-Options': 'DENY', 'Referrer-Policy': 'strict-origin-when-cross-origin' }); res.end(body); return true;
  } catch (error) { if (error.code === 'ENOENT' || error.code === 'ENOTDIR') throw new BridgeError('D_FILE', 'Archivo inexistente.', 404); throw error; }
}

export function httpHandler(broker, options = {}) {
  const port = options.port || DEFAULT_PORT;
  const origins = new Set(['https://hefestolab.github.io', 'http://127.0.0.1:' + port, ...(options.allowFileOrigin === false ? [] : ['null']), ...(options.origins || [])]);
  for (const origin of origins) if (origin !== 'null') { const url = new URL(origin); if (url.origin !== origin || !['http:', 'https:'].includes(url.protocol)) throw new Error('Origen no válido: ' + origin); }
  return async function handle(req, res) {
    const origin = req.headers.origin, host = req.headers.host;
    const headers = { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', 'Vary': 'Origin' };
    const send = (status, value) => { res.writeHead(status, headers); res.end(value === null ? '' : JSON.stringify(value)); };
    try {
      if (host !== '127.0.0.1:' + port && host !== 'localhost:' + port) throw new BridgeError('D_HOST', 'Host local no admitido.', 403);
      if (req.socket?.remoteAddress && !['127.0.0.1', '::1', '::ffff:127.0.0.1'].includes(req.socket.remoteAddress)) throw new BridgeError('D_REMOTE', 'Solo se permite loopback.', 403);
      if (req.method === 'GET' && req.url === '/health') { if (origins.has(origin)) headers['Access-Control-Allow-Origin'] = origin; return send(200, { service: 'dedalo-local-mcp', version: VERSION, territory: !!options.geoProxy }); }
      if (req.method === 'GET' && req.url === '/dedalo') { res.writeHead(302, { ...headers, Location: '/dedalo/' }); res.end(''); return; }
      if (req.method === 'GET' && await serveStatic(req, res, headers, options.staticRoot || WEB_ROOT)) return;
      if (!origins.has(origin)) throw new BridgeError('D_ORIGIN', 'Origen no autorizado.', 403);
      headers['Access-Control-Allow-Origin'] = origin;
      if (req.method === 'OPTIONS') {
        if (req.headers['access-control-request-method'] !== 'POST') throw new BridgeError('D_METHOD', 'Solo POST.', 405);
        const requested = String(req.headers['access-control-request-headers'] || '').toLowerCase().split(',').map(x => x.trim()).filter(Boolean);
        if (requested.some(x => !['content-type', 'authorization'].includes(x))) throw new BridgeError('D_HEADER', 'Cabeceras no admitidas.', 403);
        headers['Access-Control-Allow-Methods'] = 'POST'; headers['Access-Control-Allow-Headers'] = 'Content-Type, Authorization'; headers['Access-Control-Max-Age'] = '600';
        if (req.headers['access-control-request-private-network'] === 'true') headers['Access-Control-Allow-Private-Network'] = 'true';
        return send(204, null);
      }
      if (req.method !== 'POST') throw new BridgeError('D_METHOD', 'Solo POST.', 405);
      if (!/^application\/json(?:;|$)/i.test(req.headers['content-type'] || '')) throw new BridgeError('D_CONTENT_TYPE', 'Se requiere application/json.', 415);
      const route = req.url, limit = route === '/v1/result' ? 5 * 1024 * 1024 + 4096 : 1024 * 1024;
      const chunks = []; let size = 0;
      for await (const chunk of req) { size += Buffer.byteLength(chunk); if (size > limit) throw new BridgeError('D_LIMIT', 'Cuerpo demasiado grande.', 413); chunks.push(Buffer.from(chunk)); }
      let input;
      try { input = JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch { throw new BridgeError('D_JSON', 'JSON no válido.'); }
      assertJson(input, limit);
      if (route === '/v1/geodata') {
        if (!options.geoProxy) throw new BridgeError('D_GEO_UNAVAILABLE', 'Consulta territorial no disponible en este conector.', 503);
        return send(200, await options.geoProxy.request(input));
      }
      if (route === '/v1/pair') return send(200, broker.pair(input, origin));
      if (route === '/v1/poll') return send(200, broker.poll(input, origin));
      if (route === '/v1/result') return send(200, broker.submit(input, origin));
      if (route === '/v1/disconnect') { broker.authenticate(input, origin); broker.disconnect(); return send(200, { ok: true }); }
      if (route === '/v1/status') return send(200, { service: 'dedalo-local-mcp', version: VERSION });
      throw new BridgeError('D_ROUTE', 'Ruta inexistente.', 404);
    } catch (error) { return send(error.status || 400, { ok: false, code: error.code || 'D_INVALID_ARGUMENT', error: error.status ? error.message : 'Solicitud inválida.' }); }
  };
}
export { BrowserBroker };
