#!/usr/bin/env node
import { createServer } from 'node:http';
import { fileURLToPath } from 'node:url';
import { resolve } from 'node:path';
import { serveStdio, StdioServerTransport } from '@modelcontextprotocol/server/stdio';
import { BrowserBroker, createMcpServer, DEFAULT_PORT } from './connector.mjs';
import { httpHandler } from './http.mjs';
import { GeoProxy } from './geo-proxy.mjs';

export function parseOptions(args) {
  const options = { port: DEFAULT_PORT, origins: [] };
  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--port') { const port = Number(args[++i]); if (!Number.isInteger(port) || port < 1024 || port > 65535) throw new Error('Puerto no válido.'); options.port = port; }
    else if (args[i] === '--allow-origin') { const origin = args[++i]; if (!origin || origin === '*' || origin === 'null') throw new Error('Usa un origen HTTP(S) exacto.'); options.origins.push(origin); }
    else if (args[i] === '--no-file-origin') options.allowFileOrigin = false;
    else if (args[i] === '--territory') options.territory = true;
    else throw new Error('Opción desconocida: ' + args[i]);
  }
  return options;
}
export async function start(options) {
  const broker = new BrowserBroker(options), geoProxy = new GeoProxy(), http = createServer(httpHandler(broker, { ...options, geoProxy }));
  http.requestTimeout = 10000; http.headersTimeout = 10000; http.maxConnections = 16;
  await new Promise((accept, reject) => { http.once('error', reject); http.listen(options.port, '127.0.0.1', accept); });
  const transport = options.territory ? null : new StdioServerTransport(process.stdin, process.stdout, { maxBufferSize: 1024 * 1024 });
  const handle = transport ? serveStdio(() => createMcpServer(broker), { transport, onerror: error => console.error('DÉDALO MCP:', error.message) }) : null;
  let closing = false;
  const close = async () => { if (closing) return; closing = true; broker.dispose(); geoProxy.dispose(); http.closeAllConnections(); http.close(); await handle?.close(); };
  if (handle) process.stdin.once('end', close); process.once('SIGINT', close); process.once('SIGTERM', close);
  console.error('DÉDALO local en http://127.0.0.1:' + options.port + '/dedalo/?seguro&conector=1' + (handle ? '. Pide dedalo_connection a tu IA para emparejar.' : '. Territorio disponible sin cliente IA. Cierra con Ctrl+C.'));
  if (handle && process.stdin.readableEnded) await close();
  return { broker, close };
}
if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  start(parseOptions(process.argv.slice(2))).catch(error => { console.error('No se pudo iniciar DÉDALO MCP:', error.message); process.exitCode = 1; });
}
