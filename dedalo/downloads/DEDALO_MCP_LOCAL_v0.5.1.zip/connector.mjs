import { randomBytes, randomUUID, timingSafeEqual } from 'node:crypto';
import { McpServer } from '@modelcontextprotocol/server';
import { z } from 'zod';

export const VERSION = '0.5.1';
export const DEFAULT_PORT = 43127;
export const READ_QUERIES = ['status', 'project', 'commands', 'tree', 'scene', 'selection', 'audit', 'faces', 'edges', 'snapshot'];
export const COMMANDS = [
  'draw.line', 'draw.rectangle', 'draw.circle', 'draw.polygon', 'draw.arc', 'face.pushPull', 'face.offset',
  'entities.move', 'entities.rotate', 'entities.scale', 'entities.mirror', 'entities.erase',
  'group.create', 'group.explode', 'component.create', 'component.instantiate', 'component.makeUnique',
  'node.rename', 'project.rename', 'context.enter', 'context.exit', 'faces.flip', 'faces.paint', 'edges.soften',
  'guide.add', 'guides.clear', 'dim.add', 'dim.update', 'text.add', 'annot.edit',
  'mesh.ellipsoid', 'mesh.patch', 'mesh.subdivide', 'mesh.deform',
  'geo.import', 'geo.info',
  'select', 'select.all', 'select.none', 'select.connected', 'edit.undo', 'edit.redo', 'transaction.batch',
  'view.zoomExtents', 'view.set', 'view.option', 'view.projection', 'view.camera'
];
const BATCH = new Set(COMMANDS.filter(n => !n.startsWith('select') && !n.startsWith('context.') && !n.startsWith('edit.') && !n.startsWith('view.') && n !== 'transaction.batch' && n !== 'geo.info'));
const Plain = z.record(z.string(), z.unknown());
const Revision = z.number().int().nonnegative().max(Number.MAX_SAFE_INTEGER);
const Project = z.string().min(1).max(128);
const Execute = z.strictObject({ projectId: Project, expectedRevision: Revision, command: z.enum(COMMANDS), params: Plain.default({}) });
const State = z.object({ projectId: Project, revision: Revision, name: z.string().max(500).optional(), context: z.array(z.string().max(128)).max(64).optional(),
  busy: z.boolean().optional(), permissions: z.object({ write: z.boolean(), snapshot: z.boolean() }).optional(), appVersion: z.string().max(30).optional() });

export class BridgeError extends Error {
  constructor(code, message, status = 400) { super(message); this.name = 'BridgeError'; this.code = code; this.status = status; }
}
const fail = (code, message, status) => { throw new BridgeError(code, message, status); };
function sameSecret(a, b) {
  if (typeof a !== 'string' || typeof b !== 'string') return false;
  const A = Buffer.from(a), B = Buffer.from(b); return A.length === B.length && timingSafeEqual(A, B);
}
export function assertJson(value, maxBytes = 1024 * 1024) {
  let count = 0;
  function walk(x, depth) {
    if (depth > 32 || ++count > 100000) fail('D_LIMIT', 'JSON demasiado complejo.');
    if (x === null || typeof x === 'boolean' || typeof x === 'string') return;
    if (typeof x === 'number') { if (!Number.isFinite(x)) fail('D_INVALID_ARGUMENT', 'Solo se admiten números finitos.'); return; }
    if (typeof x !== 'object' || (!Array.isArray(x) && Object.getPrototypeOf(x) !== Object.prototype && Object.getPrototypeOf(x) !== null)) fail('D_INVALID_ARGUMENT', 'Se requiere JSON simple.');
    for (const [k, v] of Object.entries(x)) { if (['__proto__', 'constructor', 'prototype'].includes(k)) fail('D_INVALID_ARGUMENT', 'Clave JSON no admitida.'); walk(v, depth + 1); }
  }
  walk(value, 0);
  if (Buffer.byteLength(JSON.stringify(value), 'utf8') > maxBytes) fail('D_LIMIT', 'Mensaje demasiado grande.');
  return value;
}
export function validateExecute(input) {
  assertJson(input); const p = Execute.parse(input);
  const limits = (command, params) => {
    if (command === 'draw.arc' && params.segments !== undefined && (!Number.isSafeInteger(params.segments) || params.segments < 2 || params.segments > 720)) fail('D_LIMIT', 'El arco admite entre 2 y 720 segmentos.');
    if (command === 'draw.line' && (!Array.isArray(params.points) || params.points.length < 2 || params.points.length > 512)) fail('D_LIMIT', 'La línea admite entre 2 y 512 puntos.');
  };
  limits(p.command, p.params);
  if (p.command === 'transaction.batch') {
    const cmds = p.params.commands;
    if (!Array.isArray(cmds) || !cmds.length || cmds.length > 100) fail('D_INVALID_BATCH', 'El lote necesita entre 1 y 100 comandos.');
    for (const c of cmds) {
      if (!c || !BATCH.has(c.command)) fail('D_INVALID_BATCH', 'El lote solo admite comandos geométricos deshacibles, sin lotes anidados.');
      c.params = c.params ?? {};
      if (typeof c.params !== 'object' || Array.isArray(c.params)) fail('D_INVALID_BATCH', 'Los parámetros de cada comando deben ser un objeto.');
      limits(c.command, c.params);
    }
  }
  return p;
}

export class BrowserBroker {
  constructor(options = {}) {
    this.port = options.port || DEFAULT_PORT; this.now = options.now || Date.now;
    this.readTimeout = options.readTimeout || 15000; this.writeTimeout = options.writeTimeout || 60000;
    this.session = null; this.pending = new Map(); this.disposed = false; this.rotateCode();
  }
  rotateCode() {
    const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    this.code = [...randomBytes(8)].map(b => alphabet[b & 31]).join('');
    this.codeExpires = this.now() + 15 * 60 * 1000; this.failedPairs = 0;
  }
  connection() {
    if (this.session && this.now() - this.session.seen > 30 * 60 * 1000) this.disconnect();
    if (!this.session && this.now() >= this.codeExpires) this.rotateCode();
    const session = this.session;
    return { service: 'dedalo-local-mcp', version: VERSION, url: 'http://127.0.0.1:' + this.port,
      dedaloUrl: 'http://127.0.0.1:' + this.port + '/dedalo/?seguro&conector=1' + (session ? '' : '#dedalo-pair=' + this.code),
      connected: !!session && this.now() - session.seen <= 10000, paired: !!session, ...(session ? { projectId: session.state.projectId, revision: session.state.revision, permissions: session.permissions } :
        { code: this.code, codeExpiresAt: new Date(this.codeExpires).toISOString(), locked: this.failedPairs >= 5 }),
      instructions: session ? 'Usa dedalo_read antes de actuar y la revisión recibida para cada cambio.' : 'Abre dedaloUrl y confirma los permisos en DÉDALO. El enlace rellena un código de un uso válido 15 minutos; no conecta sin tu confirmación. Como alternativa, pulsa Unir IA e introduce code. No introduzcas claves de proveedor.' };
  }
  pair(input, origin) {
    assertJson(input, 16384);
    if (this.disposed || this.session) fail('D_ALREADY_PAIRED', 'Desconecta la sesión anterior antes de emparejar otra pestaña.', 409);
    if (this.now() >= this.codeExpires) fail('D_PAIR_EXPIRED', 'Código caducado; solicita dedalo_connection de nuevo.', 401);
    if (this.failedPairs >= 5) fail('D_PAIR_LOCKED', 'Demasiados intentos. Espera a que caduque el código.', 429);
    const code = typeof input.code === 'string' ? input.code.trim().replace(/[-\s]/g, '').toUpperCase() : '';
    if (!sameSecret(code, this.code)) { this.failedPairs++; fail('D_PAIR_CODE', 'Código de emparejamiento incorrecto.', 401); }
    const state = State.parse(input.state);
    const client = z.strictObject({ name: z.string().min(1).max(120), version: z.string().max(30) }).parse(input.client);
    const permissions = z.strictObject({ write: z.boolean(), snapshot: z.boolean() }).parse(input.permissions || { write: false, snapshot: false });
    this.session = { id: randomUUID(), token: randomBytes(32).toString('base64url'), origin, state, client, permissions, seen: this.now() };
    this.code = ''; return { token: this.session.token, sessionId: this.session.id, permissions };
  }
  authenticate(input, origin) {
    const s = this.session;
    if (!s || s.origin !== origin || !sameSecret(input.sessionId, s.id) || !sameSecret(input.token, s.token)) fail('D_UNAUTHORIZED', 'Sesión local no autorizada.', 401);
    if (this.now() - s.seen > 30 * 60 * 1000) { this.disconnect(); fail('D_SESSION_EXPIRED', 'La sesión local ha caducado.', 401); }
    return s;
  }
  poll(input, origin) {
    const s = this.authenticate(input, origin), state = State.parse(input.state);
    if (state.projectId !== s.state.projectId) { this.disconnect(); fail('D_PROJECT_CHANGED', 'El proyecto cambió; vuelve a emparejar.', 409); }
    s.state = state; s.seen = this.now();
    if ([...this.pending.values()].some(p => p.delivered)) return { request: null };
    const item = this.pending.values().next().value;
    if (!item) return { request: null };
    item.delivered = true; return { request: { id: item.id, action: item.action, payload: item.payload } };
  }
  submit(input, origin) {
    const s = this.authenticate(input, origin), item = this.pending.get(input.id);
    if (!item || !item.delivered) fail('D_UNKNOWN_REQUEST', 'Solicitud inexistente o caducada. Relee el estado antes de reintentar cambios.', 410);
    assertJson(input.result, 5 * 1024 * 1024);
    if (!input.result || typeof input.result.ok !== 'boolean' || input.result.projectId !== s.state.projectId || !Number.isSafeInteger(input.result.revision) || input.result.revision < 0) fail('D_INVALID_RESULT', 'Respuesta de navegador no válida.');
    s.seen = this.now(); s.state.revision = input.result.revision; this.finish(item.id, input.result); return { ok: true };
  }
  request(action, payload, signal) {
    if (this.disposed) return Promise.reject(new BridgeError('D_CLOSED', 'Conector cerrado.'));
    const s = this.session;
    if (!s) return Promise.reject(new BridgeError('D_NOT_CONNECTED', 'Empareja DÉDALO con dedalo_connection.'));
    if (this.now() - s.seen > 10000) return Promise.reject(new BridgeError('D_BROWSER_DISCONNECTED', 'DÉDALO no responde; comprueba su pestaña y relee el estado.'));
    if (this.pending.size >= 10) return Promise.reject(new BridgeError('D_QUEUE_FULL', 'Hay demasiadas solicitudes pendientes.'));
    if (action === 'execute') {
      payload = validateExecute(payload);
      if (!s.permissions.write) return Promise.reject(new BridgeError('D_READ_ONLY', 'La pestaña solo autorizó lectura.'));
      if (s.state.busy) return Promise.reject(new BridgeError('D_BUSY', 'Termina la herramienta activa antes de modificar.'));
      if (payload.projectId !== s.state.projectId || payload.expectedRevision !== s.state.revision) return Promise.reject(new BridgeError('D_STALE_DOCUMENT', 'Proyecto o revisión desactualizados; relee el estado.'));
    } else if (action !== 'read' || !READ_QUERIES.includes(payload.query)) return Promise.reject(new BridgeError('D_UNKNOWN_ACTION', 'Acción no permitida.'));
    else if (payload.query === 'snapshot' && !s.permissions.snapshot) return Promise.reject(new BridgeError('D_SNAPSHOT_DENIED', 'La pestaña no autorizó capturas.'));
    if (signal?.aborted) return Promise.reject(new BridgeError('D_CANCELLED', 'Solicitud cancelada antes de enviar.'));
    return new Promise((resolve, reject) => {
      const item = { id: randomUUID(), action, payload: assertJson(payload), delivered: false, resolve, reject };
      item.timer = setTimeout(() => this.finish(item.id, null, new BridgeError(item.delivered && action === 'execute' ? 'D_RESULT_UNKNOWN' : 'D_TIMEOUT',
        item.delivered && action === 'execute' ? 'Se perdió la respuesta; puede haberse aplicado. Relee antes de reintentar.' : 'La solicitud caducó sin respuesta.')), action === 'execute' ? this.writeTimeout : this.readTimeout);
      item.abort = () => this.finish(item.id, null, new BridgeError(item.delivered && action === 'execute' ? 'D_RESULT_UNKNOWN' : 'D_CANCELLED', 'Solicitud cancelada; relee el estado si llegó al navegador.'));
      item.signal = signal; signal?.addEventListener('abort', item.abort, { once: true }); this.pending.set(item.id, item);
    });
  }
  finish(id, result, error) {
    const item = this.pending.get(id); if (!item) return;
    this.pending.delete(id); clearTimeout(item.timer); item.signal?.removeEventListener('abort', item.abort);
    if (error) item.reject(error); else item.resolve(result);
  }
  disconnect() {
    this.session = null;
    for (const p of [...this.pending.values()]) this.finish(p.id, null, new BridgeError(p.delivered && p.action === 'execute' ? 'D_RESULT_UNKNOWN' : 'D_DISCONNECTED', 'Sesión desconectada; relee antes de reintentar cambios.'));
    this.rotateCode();
  }
  dispose() { this.disconnect(); this.disposed = true; }
}

function toolResult(value) {
  assertJson(value, 5 * 1024 * 1024);
  if (value.ok && typeof value.result?.png === 'string' && /^data:image\/png;base64,[A-Za-z0-9+/=]+$/.test(value.result.png)) {
    const metadata = { ...value, result: { image: 'PNG snapshot', mimeType: 'image/png' } };
    return { content: [{ type: 'image', mimeType: 'image/png', data: value.result.png.slice('data:image/png;base64,'.length) }, { type: 'text', text: JSON.stringify(metadata) }], structuredContent: metadata };
  }
  return { content: [{ type: 'text', text: JSON.stringify(value) }], structuredContent: value, ...(value.ok === false ? { isError: true } : {}) };
}
const errorResult = error => toolResult({ ok: false, code: error.code || 'D_INVALID_ARGUMENT', error: error instanceof z.ZodError ? 'Parámetros no válidos: ' + error.issues.map(i => i.path.join('.') + ' ' + i.message).join('; ') : error.message });
export function createMcpServer(broker) {
  const server = new McpServer({ name: 'dedalo-local', version: VERSION }, { maxToolInputElements: 100000 });
  const wrap = fn => async (p, ctx) => { try { return toolResult(await fn(p, ctx)); } catch (error) { return errorResult(error); } };
  server.registerTool('dedalo_connection', { description: 'Devuelve un enlace local que rellena un código efímero de emparejamiento. El humano abre dedaloUrl y confirma los permisos en DÉDALO. No necesita claves de proveedor.',
    inputSchema: z.strictObject({ reset: z.boolean().optional().describe('Solo true para revocar la pestaña anterior y generar otro código de emparejamiento.') }), annotations: { readOnlyHint: false, destructiveHint: false, openWorldHint: false } }, wrap(p => { if (p.reset) broker.disconnect(); return broker.connection(); }));
  server.registerTool('dedalo_read', { description: 'Lee estado/revisión y datos de la pestaña autorizada. Usa status antes de ejecutar; commands documenta parámetros nativos. project devuelve el documento completo; usa tree/scene/faces para consultas acotadas. Las fotos se interpretan en tu cliente de IA.',
    inputSchema: z.strictObject({ query: z.enum(READ_QUERIES) }), annotations: { readOnlyHint: true, openWorldHint: false } }, wrap((p, ctx) => broker.request('read', p, ctx.mcpReq?.signal || ctx.signal)));
  server.registerTool('dedalo_execute', { description: 'Ejecuta un comando DÉDALO permitido sobre projectId y expectedRevision exactos. params es JSON del comando nativo, validado también por DÉDALO. Relee tras cada resultado. No admite archivos, shell, eval ni nuevo/cargar proyecto. Un lote solo admite comandos geométricos deshacibles.',
    inputSchema: Execute, annotations: { readOnlyHint: false, destructiveHint: true, idempotentHint: false, openWorldHint: false } }, wrap((p, ctx) => broker.request('execute', p, ctx.mcpReq?.signal || ctx.signal)));
  return server;
}
