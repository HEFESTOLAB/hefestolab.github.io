# DÉDALO TERRITORIO + MCP LOCAL v0.5.1

Conecta tu cliente de IA a una pestaña DÉDALO y consulta datos territoriales públicos desde tu ordenador. El conector escucha exclusivamente en `127.0.0.1`; para IA usa tu cliente MCP por stdio. HEFESTOLAB no aporta claves, no llama a proveedores de modelos ni recibe los comandos del puente. Tu cliente y tu proveedor de IA sí pueden recibir los datos que autorices compartir.

Es una primera integración experimental. Se han probado negociación MCP, controles y modelado completo en CPU con transporte en memoria y HTTP simulado. **No se ha arrancado aquí un servidor ni se ha probado una sesión gráfica con Claude/Codex o el permiso de un navegador real.** No se promete compatibilidad con cualquier IA, navegador, plan o política de empresa.

## 1. Preparación una sola vez

**Solo territorio, sin IA:** instala Node.js 22 o posterior, extrae este ZIP y abre `INICIAR_TERRITORIO.cmd` en Windows. También puedes ejecutar `node server.mjs --territory` desde esta carpeta. Abre `http://127.0.0.1:43127/dedalo/?seguro&conector=1` y usa Territorio. No necesitas cuenta de IA, código de emparejamiento ni npm. La ventana debe permanecer abierta; cierra con Ctrl+C. No ejecutes a la vez esta opción y el MCP de un cliente en el mismo puerto. Este arranque no abre el navegador automáticamente ni modifica configuraciones.

**Alternativa experimental para Claude Desktop:** el archivo
`DEDALO_MCP_CLAUDE_v0.5.1.mcpb` contiene este conector con manifiesto MCPB validado.
Un Claude Desktop compatible aporta su runtime Node, que debe satisfacer >=22;
no necesitas añadir manualmente el JSON si la instalación de extensiones está
admitida. No se ha probado la importación del paquete en un host real ni su
runtime. El puerto se elige durante la configuración de la extensión y debe
coincidir con el panel Unir IA. El ZIP es la alternativa para otros clientes.

1. Usa un cliente que admita MCP **local stdio**: por ejemplo, Claude Desktop, Claude Code o Codex local. Una conexión MCP que solo acepte URL remotas desde la nube no puede alcanzar el localhost de tu ordenador.
2. Instala Node.js 22 o posterior desde su distribución oficial y comprueba `node --version`. Este ZIP no instala Node ni contiene un ejecutable. Incluye las dependencias de producción, por lo que **no necesitas npm para usar el ZIP completo**.
3. Extrae el ZIP en una carpeta estable. Los ejemplos siguientes usan `C:/Herramientas/DEDALO_MCP_LOCAL/server.mjs`: sustituye esa ruta por la tuya. Conserva juntas las fuentes, `node_modules` y `web`.
4. Registra el servidor en tu cliente. Hazlo en un único cliente a la vez para el puerto elegido; dos procesos no pueden ocupar el mismo puerto.

El SDK oficial usado es `@modelcontextprotocol/server` **2.3.1**, con Zod **4.6.7** y lockfile. `serveStdio` atiende tanto la era `2026-07-28` como las conexiones anteriores con `initialize`. [SDK y transporte oficial](https://ts.sdk.modelcontextprotocol.io/v2/serving/stdio), [versiones oficiales](https://github.com/modelcontextprotocol/typescript-sdk/releases)

### Codex local

Puedes agregarlo desde la configuración MCP de tu cliente o ejecutar tú esta orden una sola vez:

```text
codex mcp add dedalo -- node "C:/Herramientas/DEDALO_MCP_LOCAL/server.mjs"
```

Alternativa de configuración TOML: **añade** esta entrada a tu configuración existente, sin sustituir otras opciones o servidores. Ajusta la ruta; si Node no está en PATH, usa la ruta absoluta de `node.exe` como `command`.

```toml
[mcp_servers.dedalo]
command = "node"
args = ["C:/Herramientas/DEDALO_MCP_LOCAL/server.mjs"]
startup_timeout_sec = 20
tool_timeout_sec = 90
```

La documentación oficial de OpenAI describe stdio y la configuración compartida de los clientes locales en `config.toml`. La disponibilidad de los controles de interfaz depende de la versión instalada. [OpenAI Docs: MCP](https://learn.chatgpt.com/docs/extend/mcp?surface=cli)

### Claude Code

Ejecuta tú una vez, en el ámbito que quieras usar:

```text
claude mcp add --transport stdio --scope user dedalo -- node "C:/Herramientas/DEDALO_MCP_LOCAL/server.mjs"
```

`--` separa las opciones de Claude de la orden que inicia el conector. [Claude Code: stdio local](https://code.claude.com/docs/en/mcp)

### Claude Desktop

Para configuración manual, abre los ajustes de desarrollador de **la instalación que estés utilizando** y su opción de editar configuración. Guarda antes una copia de tu archivo. Añade la entrada `dedalo` dentro del objeto `mcpServers` ya existente; conserva los demás servidores y ajustes. Este programa no busca ni modifica configuraciones de Claude.

```json
{
  "mcpServers": {
    "dedalo": {
      "command": "node",
      "args": ["C:/Herramientas/DEDALO_MCP_LOCAL/server.mjs"]
    }
  }
}
```

El ejemplo es un documento completo solo cuando aún no tienes configuración. Si ya la tienes, agrega únicamente la entrada interior. Reinicia el cliente para cargarla y comprueba que aparecen las herramientas DÉDALO. La guía oficial MCP muestra el flujo de configuración manual de Claude Desktop. [Conectar servidores locales](https://modelcontextprotocol.io/docs/2026-07-28/develop/connect-local-servers)

Claude también admite extensiones `.mcpb` con instalación desde Ajustes > Extensiones; este ZIP es un servidor stdio, **no una extensión MCPB**, y no debe importarse como si lo fuera. [Claude Desktop: extensiones locales](https://support.claude.com/en/articles/10949351-getting-started-with-local-mcp-servers-on-claude-desktop)

## 2. Conectar la pestaña cada sesión

1. En tu chat de IA escribe: **«Usa `dedalo_connection` y dame el enlace `dedaloUrl` para conectar DÉDALO.»** La herramienta devuelve un enlace local con un código de ocho caracteres, válido 15 minutos. No se introduce ninguna clave de modelo en la web.
2. Abre ese enlace. Sirve la copia de DÉDALO incluida en el conector y rellena el código de conexión. El código viaja en el fragmento `#dedalo-pair=…`, no en la consulta enviada al servidor; la aplicación lo retira de la barra de direcciones. No compartas este enlace mientras sea válido. No contiene un token de sesión.
3. **Confirma los permisos en Unir IA.** Abrir el enlace no autoriza por sí solo: elige lectura, modificación y, opcionalmente, capturas. Autorizar modificación permite que tu cliente IA ejecute operaciones compatibles durante esa sesión; las confirmaciones adicionales dependen de tu cliente IA. También puedes usar DÉDALO online e introducir manualmente el campo `code` y el puerto. La copia local solo está disponible mientras se ejecuta el conector.
4. En la web online, acepta el permiso de conexión a loopback si el navegador lo solicita. Si falla por soporte o política del navegador, usa la copia local de la URL anterior; comparte el mismo origen HTTP con el puente.
5. Pide: **«Usa `dedalo_read` con `query: status`; después consulta los comandos y el árbol del proyecto.»**
6. Para empezar a modelar: **«Modela una caja de 2 × 1 × 1 metros; consulta el estado antes de cada cambio y conserva el proyecto abierto.»** Para una foto, adjúntala a tu cliente IA y pide que interprete sus formas, aclare escala y medidas desconocidas, y construya una aproximación mediante las herramientas DÉDALO. La interpretación de la imagen la realiza tu modelo; el conector no abre archivos ni analiza fotografías por su cuenta.
7. Termina con **Desconectar** en DÉDALO. Cambiar o cargar un proyecto revoca la sesión. Solo se empareja una pestaña por conector.

Si la pestaña se cerró o quedó una sesión antigua, pide **«Usa `dedalo_connection` con `reset: true` y dame un código nuevo.»** Revoca el token anterior y debes volver a autorizar en la web. No reintentes a ciegas una modificación cuya respuesta se perdió: primero relee el modelo.

Los navegadores con Local Network Access pueden exigir permiso, y existen diferencias de soporte. El conector no desactiva ninguna protección ni instala certificados. [MDN: red local y loopback](https://developer.mozilla.org/en-US/docs/Web/Security/Defenses/Local_network_access)

## Herramientas y límites

- `dedalo_connection({reset?:boolean})`: código temporal y estado del puente. `reset:true` desconecta el emparejamiento anterior.
- `dedalo_read({query})`: `status`, `commands`, `tree`, `scene`, `selection`, `audit`, `faces`, `edges`, `project`, `snapshot`. `project` devuelve el proyecto completo y puede ser grande; usa consultas acotadas. `snapshot` requiere permiso separado y devuelve imagen PNG al cliente.
- `dedalo_execute({projectId,expectedRevision,command,params})`: solo comandos permitidos. Usa los IDs y la revisión de la última lectura. Lee `commands` para los parámetros nativos. Modelado, selección, contexto, deshacer/rehacer, grupos/componentes, cotas, materiales, mallas orgánicas y vistas están disponibles según la aplicación.

No hay herramientas para shell, `eval`, abrir rutas arbitrarias, credenciales, cargar un proyecto ni borrar todo mediante `model.new`. Las herramientas de geometría sí pueden borrar objetos con permiso de modificación. Una imagen no proporciona automáticamente medidas fiables ni crea un sistema B-Rep/NURBS.

El lote `transaction.batch` admite de 1 a 100 comandos geométricos deshacibles, sin lotes anidados, cambios de contexto ni consultas. Peticiones: 1 MiB; resultados del puente: 5 MiB; la aplicación aplica un margen de 4 MiB. Cola: 10 solicitudes, una en vuelo. Lecturas: 15 s; modificaciones: 60 s; no hay reenvío automático de modificaciones. Una respuesta perdida se marca como estado indeterminado. La pestaña comprueba proyecto, revisión y herramienta inactiva inmediatamente antes de actuar.

El servidor se enlaza exclusivamente a `127.0.0.1`. El puerto predeterminado es 43127. Orígenes predeterminados: `https://hefestolab.github.io`, la copia servida por ese mismo puerto y origen `null` de archivos locales. Los endpoints de IA requieren además código de un uso para emparejar y token para cada intercambio; la consulta de datos territoriales públicos no necesita ese emparejamiento. Puedes deshabilitar archivos locales con `--no-file-origin`. Para otro dominio agrega `--allow-origin https://tu-dominio.example` a los argumentos del servidor. No uses comodines. El origen no incluye la ruta de un repositorio: todos los proyectos bajo el mismo dominio GitHub comparten origen.

Si el puerto está ocupado, cambia los argumentos a `[..., "--port", "43128"]` y usa ese puerto en Unir IA. Nunca abras el puerto en tu router, crees túneles públicos o cambies la dirección de escucha para compartirlo por internet.

El token aleatorio de sesión solo vive en memoria; el código es de un uso, caduca a los 15 minutos y se bloquea tras cinco intentos erróneos. Esta caducidad afecta al emparejamiento, no a la duración de una sesión activa. La sesión se revoca tras 30 minutos sin comunicación de la pestaña; los sondeos de una pestaña abierta renuevan su actividad. Los tokens no se guardan en modelos, configuración, registros ni almacenamiento web. El conector no realiza conexiones a APIs de IA. Tu cliente administra su cuenta y sus límites; el uso de la IA puede tener coste.

## Territorio: fuentes y límites

`POST /v1/geodata` consulta únicamente operaciones predeterminadas y no requiere emparejar una IA. Mantiene los mismos controles de Host loopback y origen del puente. El navegador envía una operación y parámetros tipados; no puede proporcionar URLs, cabeceras, filtros ni consultas Overpass arbitrarias.

- `catastro.parcels` y `catastro.buildings`: `{bbox:[oeste,sur,este,norte]}` en EPSG:4326. WFS 2.0 de Catastro devuelve GML; edificios usa `BU.BuildingPart`. Máximo 1 km², 5.000 elementos solicitados y 16 MiB. La referencia catastral pública de parcela de 14 caracteres permite también `catastro.parcelByReference` y `catastro.buildingsByReference`, con `{reference}` y consultas almacenadas fijas. No se consultan datos protegidos de titulares.
- `ign.terrain`: la misma bbox; devuelve ArcGrid ASCII de **33 × 33** muestras de `Elevacion4258_5` mediante WCS. Fuente MDT05 y CRS horizontal EPSG:4258. El espaciado de salida depende de la zona y del remuestreo bilineal; seleccionar 1 km de lado produce aproximadamente 30 m entre muestras, no un terreno completo cada 5 m. Máximo 1 MiB. La aplicación debe conservar la referencia vertical declarada por la fuente, sin convertirla en altura elipsoidal.
- `osm.trees` y `osm.context`: consultas fijas de árboles y, en contexto, vías, agua y parques/bosques representados por nodos y vías. Sin relaciones multipolígono. Máximo 1 km², 4.000 elementos y 2 MiB; la cobertura y los atributos varían. No se infieren árboles reales donde no hay datos.
- `address.candidates`: `{query}` de 3–200 caracteres, cinco candidatos de CartoCiudad. `address.find`: `{query,id,type}` del candidato elegido. Máximo 2 MiB. Las direcciones y zonas consultadas se transmiten a sus proveedores públicos; no introduzcas información privada en la búsqueda.

Respuesta común: `{ok,operation,format,text,source:{provider,url,crs,attribution},cached,retrievedAt}`. `format` es `gml`, `ascii-grid` o `json`; las coordenadas del GML EPSG:4326 usan el orden formal latitud/longitud. No hay transformación de ejes oculta en el proxy. La aplicación interpreta, recorta y genera la geometría del proyecto. Las plantas de Catastro sirven para una extrusión estimada; no aportan por sí mismas un techo medido ni fachadas detalladas.

Las conexiones salientes son HTTPS con validación TLS habilitada y sin redirecciones. Una consulta de red activa, cuatro en espera, intervalo mínimo 750 ms, plazo 35 s para OSM y 20 s para las demás fuentes, caché solo en memoria de cinco minutos (16 entradas, 32 MiB). El límite comprende también la lectura completa de la respuesta. Respuestas grandes, consultas parciales o falta de cobertura producen error para que reduzcas la zona o reintentes. Los proveedores pueden imponer límites, cambiar o interrumpir sus servicios; no se ofrece acceso ilimitado ni cobertura nacional uniforme. El proxy no publica ni almacena un repositorio de datos.

Si el navegador o PowerShell sí accede a las fuentes, pero Node muestra `UNABLE_TO_VERIFY_LEAF_SIGNATURE`, puede que tu red use un certificado de confianza instalado en Windows que Node no esté consultando. En Node **22.20.0**, verificado durante el desarrollo, puedes ejecutar `node --use-system-ca server.mjs --territory`; para MCP añade `"--use-system-ca"` antes de la ruta `server.mjs` en sus argumentos. En otras versiones comprueba que `node --help` ofrece esa opción o actualiza Node. Usa únicamente certificados de confianza del sistema; no desactives la verificación TLS ni uses `NODE_TLS_REJECT_UNAUTHORIZED=0`. [Node: certificados del sistema](https://nodejs.org/api/cli.html#--use-system-ca)

La copia local puede mostrar teselas `https://tile.openstreetmap.org` como mapa de selección, con atribución; las teselas no pasan por este proxy ni se descargan como un atlas. Se deben respetar las condiciones del servicio y evitar descargas masivas. [Política de teselas OSM](https://operations.osmfoundation.org/policies/tiles/)

Fuentes y condiciones oficiales: [Catastro INSPIRE](https://www.catastro.hacienda.gob.es/webinspire/), [licencia Catastro](https://www.catastro.hacienda.gob.es/webinspire/documentos/Licencia.pdf), [servicios IGN](https://www.ign.es/web/ign/portal/ide-area-nodo-ide-ign), [licencia IGN](https://www.ign.es/web/politica-datos), [CartoCiudad](https://www.cartociudad.es/web/portal/directorio-de-servicios/geoprocesamiento), [OpenStreetMap](https://www.openstreetmap.org/copyright). Conserva atribución, fecha de consulta y procedencia al exportar o distribuir resultados. Las condiciones de Catastro y de cada fuente deben revisarse para el uso concreto.

## Desarrollo y verificación

Para fuentes sin dependencias: `npm ci --ignore-scripts`. Para los tests: `npm test` en el árbol de desarrollo. Los tests usan el SDK real, streams e intercambio HTTP simulados, sin listeners. La copia de distribución omite tests y dependencias de cliente utilizadas solo para pruebas.

Verificado en Node 22.20.0: negociación antigua y moderna, schemas MCP reales, stdio limpio, emparejamiento y revocación, permisos, origen/Host, cola, timeout/cancelación, revisión, listas de comandos, rutas estáticas, e integración CPU completa SDK → puente → documento real (rectángulo, extrusión, rechazo de revisión antigua y deshacer). Las pruebas territoriales HTTP simuladas cubren plantillas fijas, bbox, formatos/ejes, tamaño, cola, caché, errores y timeout sin sockets. Las consultas mínimas de fuente realizadas durante el desarrollo verifican disponibilidad puntual, no garantizan servicio continuado. Pendiente: aceptación con cliente IA real, navegador/HTTPS reales, arranque de listener y carga visual de territorio. El código que inicia el listener existe y se ejecuta al arrancarlo el usuario o su cliente; no se ha ejecutado durante estas pruebas.

La copia web servida está limitada a `web/dedalo`; no expone el resto del disco ni el propio `node_modules` por HTTP. Se rechazan rutas con recorrido, archivos ocultos y enlaces simbólicos. Incluye los avisos de licencia de cada dependencia en su paquete y en `THIRD_PARTY_NOTICES.txt`. No contiene modelos privados, DEDALO_PRIVADO ni el puente privado HEFESTO.
