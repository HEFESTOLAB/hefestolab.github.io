// Fixed public-data requests. This is not a general URL proxy or an AI endpoint.
import { BridgeError, assertJson } from './connector.mjs';

export const GEO_OPERATIONS = ['catastro.parcels', 'catastro.buildings', 'catastro.parcelByReference', 'catastro.buildingsByReference', 'ign.terrain', 'osm.trees', 'osm.context', 'address.candidates', 'address.find'];
const MiB = 1024 * 1024;
const error = (code, message, status = 400) => { throw new BridgeError(code, message, status); };
const ATTRIBUTION = {
  catastro: 'Dirección General del Catastro. Cartografía catastral INSPIRE. Condiciones de acceso y uso del proveedor.',
  ign: 'Obra derivada de MDT05 © Instituto Geográfico Nacional de España. CC BY 4.0.',
  osm: '© OpenStreetMap contributors, ODbL 1.0. https://www.openstreetmap.org/copyright',
  address: 'CartoCiudad © Instituto Geográfico Nacional de España y productores colaboradores. CC BY 4.0.'
};
function keys(input, allowed) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) error('D_GEO_ARGUMENT', 'Se requiere un objeto de operación territorial.');
  if (Object.keys(input).some(k => !allowed.includes(k))) error('D_GEO_ARGUMENT', 'Campo territorial no admitido. No se admiten URLs ni consultas libres.');
}
function bbox(value) {
  if (!Array.isArray(value) || value.length !== 4 || !value.every(Number.isFinite)) error('D_GEO_BBOX', 'bbox debe ser [oeste,sur,este,norte] en grados.');
  const [w, s, e, n] = value;
  if (!(w < e && s < n && w >= -19 && e <= 5 && s >= 27 && n <= 44.5)) error('D_GEO_BBOX', 'Selecciona una zona dentro de la cobertura española.');
  const width = (e - w) * Math.PI / 180 * 6371008.8 * Math.cos((s + n) * Math.PI / 360), height = (n - s) * Math.PI / 180 * 6371008.8;
  if (width > 1100 || height > 1100 || width * height > 1000000.01) error('D_GEO_BBOX', 'La selección admite como máximo 1 km² y 1,1 km por lado.');
  return value.map(v => Number(v.toFixed(9)));
}
function query(value) {
  if (typeof value !== 'string' || value.trim().length < 3 || value.length > 200 || /[\x00-\x1f\x7f]/.test(value)) error('D_GEO_ARGUMENT', 'La dirección debe tener entre 3 y 200 caracteres.');
  return value.trim();
}
function makeUrl(base, params) { const url = new URL(base); for (const [key, value] of Object.entries(params)) url.searchParams.set(key, String(value)); return url.href; }

export function geoRequest(input) {
  assertJson(input, 4096);
  if (!GEO_OPERATIONS.includes(input?.operation)) error('D_GEO_OPERATION', 'Operación territorial no admitida.');
  const operation = input.operation;
  let normalized, url, body, format, provider, crs, attribution, maxBytes;
  if (operation.startsWith('catastro.')) {
    const byReference = operation.endsWith('ByReference');
    keys(input, ['operation', byReference ? 'reference' : 'bbox']);
    const buildings = operation === 'catastro.buildings' || operation === 'catastro.buildingsByReference';
    const params = { service: 'WFS', version: '2.0.0', request: 'GetFeature', srsName: 'EPSG:4326' };
    if (byReference) {
      if (typeof input.reference !== 'string' || !/^[0-9A-Z]{14}$/i.test(input.reference)) error('D_GEO_ARGUMENT', 'La referencia de parcela requiere 14 caracteres alfanuméricos.');
      normalized = { operation, reference: input.reference.toUpperCase() };
      params.STOREDQUERY_ID = buildings ? 'GETBUILDINGPARTBYPARCEL' : 'GetParcel'; params.REFCAT = normalized.reference;
    } else {
      normalized = { operation, bbox: bbox(input.bbox) }; const [w, s, e, n] = normalized.bbox;
      params.typeNames = buildings ? 'BU.BuildingPart' : 'CP.CadastralParcel';
      // WFS2 EPSG:4326 uses formal latitude/longitude axis order.
      params.bbox = [s, w, n, e, 'urn:ogc:def:crs:EPSG::4326'].join(','); params.count = 5000;
    }
    url = makeUrl('https://ovc.catastro.meh.es/INSPIRE/' + (buildings ? 'wfsBU.aspx' : 'wfsCP.aspx'), params);
    format = 'gml'; provider = 'Dirección General del Catastro'; crs = 'EPSG:4326'; attribution = ATTRIBUTION.catastro; maxBytes = 16 * MiB;
  } else if (operation === 'ign.terrain') {
    keys(input, ['operation', 'bbox']); normalized = { operation, bbox: bbox(input.bbox) };
    url = makeUrl('https://servicios.idee.es/wcs-inspire/mdt', { request: 'GetCoverage', service: 'WCS', version: '1.0.0', coverage: 'Elevacion4258_5', interpolationMethod: 'bilinear', crs: 'EPSG:4258', bbox: normalized.bbox.join(','), format: 'ArcGrid', width: 33, height: 33 });
    format = 'ascii-grid'; provider = 'IGN / CNIG'; crs = 'EPSG:4258'; attribution = ATTRIBUTION.ign; maxBytes = MiB;
  } else if (operation === 'osm.trees' || operation === 'osm.context') {
    keys(input, ['operation', 'bbox']); normalized = { operation, bbox: bbox(input.bbox) }; const [w, s, e, n] = normalized.bbox;
    const bounds = `(${s},${w},${n},${e})`;
    const data = operation === 'osm.trees' ? `node["natural"="tree"]${bounds};out body;` : `(node["natural"="tree"]${bounds};way["natural"~"^(wood|water)$"]${bounds};way["landuse"="forest"]${bounds};way["leisure"="park"]${bounds};way["highway"]${bounds};way["waterway"]${bounds};);out body geom;`;
    url = 'https://overpass-api.de/api/interpreter'; body = new URLSearchParams({ data: '[out:json][timeout:12][maxsize:16777216];' + data }).toString();
    format = 'json'; provider = 'OpenStreetMap / Overpass'; crs = 'EPSG:4326'; attribution = ATTRIBUTION.osm; maxBytes = 2 * MiB;
  } else {
    keys(input, operation === 'address.find' ? ['operation', 'query', 'id', 'type'] : ['operation', 'query']);
    normalized = { operation, query: query(input.query) }; const params = { q: normalized.query };
    if (operation === 'address.find') {
      if (typeof input.id !== 'string' || !/^[0-9A-Za-z_.:-]{1,80}$/.test(input.id) || typeof input.type !== 'string' || !/^[a-z_ ]{1,40}$/.test(input.type)) error('D_GEO_ARGUMENT', 'Selecciona un candidato válido del geocodificador.');
      normalized.id = input.id; normalized.type = input.type; params.id = input.id; params.type = input.type;
    } else params.limit = 5;
    url = makeUrl('https://www.cartociudad.es/geocoder/api/geocoder/' + (operation === 'address.find' ? 'find' : 'candidates'), params);
    format = 'json'; provider = 'CartoCiudad / IGN'; crs = 'EPSG:4326'; attribution = ATTRIBUTION.address; maxBytes = 2 * MiB;
  }
  return { key: JSON.stringify(normalized), operation, url, body, format, maxBytes, source: { provider, url, crs, attribution } };
}

export class GeoProxy {
  constructor(options = {}) {
    this.fetch = options.fetch || globalThis.fetch; this.now = options.now || Date.now;
    this.delay = options.delay ?? 750; this.timeout = options.timeout ?? null;
    this.maxCacheBytes = options.maxCacheBytes ?? 32 * MiB; this.cacheBytes = 0; this.cache = new Map();
    this.queue = []; this.inflight = new Map(); this.active = null; this.timer = null; this.lastStarted = 0; this.closed = false;
  }
  request(input) {
    let item; try { item = geoRequest(input); } catch (e) { return Promise.reject(e); }
    if (this.closed) return Promise.reject(new BridgeError('D_GEO_CLOSED', 'Conector territorial cerrado.', 503));
    const cached = this.cache.get(item.key);
    if (cached && this.now() - cached.time < 5 * 60 * 1000) { this.cache.delete(item.key); this.cache.set(item.key, cached); return Promise.resolve({ ...cached.value, cached: true }); }
    if (cached) { this.cache.delete(item.key); this.cacheBytes -= cached.bytes; }
    if (this.inflight.has(item.key)) return this.inflight.get(item.key);
    if (this.queue.length >= 4) return Promise.reject(new BridgeError('D_GEO_BUSY', 'Hay demasiadas consultas territoriales. Espera y vuelve a intentarlo.', 429));
    const promise = new Promise((resolve, reject) => { this.queue.push({ ...item, resolve, reject }); });
    this.inflight.set(item.key, promise); this.drain(); return promise;
  }
  drain() {
    if (this.closed || this.active || this.timer || !this.queue.length) return;
    const wait = Math.max(0, this.delay - (this.now() - this.lastStarted));
    if (wait) { this.timer = setTimeout(() => { this.timer = null; this.drain(); }, wait); return; }
    const item = this.queue.shift(); this.active = item; this.lastStarted = this.now();
    this.load(item).then(value => {
      const bytes = Buffer.byteLength(value.text);
      while (this.cache.size >= 16 || this.cacheBytes + bytes > this.maxCacheBytes) {
        const oldest = this.cache.keys().next().value; if (oldest === undefined) break;
        this.cacheBytes -= this.cache.get(oldest).bytes; this.cache.delete(oldest);
      }
      if (!this.closed && bytes <= this.maxCacheBytes) { this.cache.set(item.key, { value, bytes, time: this.now() }); this.cacheBytes += bytes; }
      item.resolve(value);
    }, error => item.reject(error)).finally(() => { this.inflight.delete(item.key); this.active = null; this.drain(); });
  }
  async load(item) {
    const controller = new AbortController(); item.controller = controller;
    const timer = setTimeout(() => controller.abort(), this.timeout ?? (item.operation.startsWith('osm.') ? 35000 : 20000));
    try {
      const response = await this.fetch(item.url, { method: item.body ? 'POST' : 'GET', redirect: 'error', signal: controller.signal,
        headers: { Accept: item.format === 'json' ? 'application/json' : 'text/plain, application/xml', 'User-Agent': 'DEDALO/0.5.1 (HEFESTOLAB; small public geodata query)', ...(item.body ? { 'Content-Type': 'application/x-www-form-urlencoded' } : {}) }, ...(item.body ? { body: item.body } : {}) });
      if (!response.ok) error('D_GEO_UPSTREAM', 'El proveedor territorial respondió HTTP ' + response.status + '. Prueba una zona menor o inténtalo después.', 502);
      const length = Number(response.headers.get('content-length'));
      if (Number.isFinite(length) && length > item.maxBytes) error('D_GEO_LIMIT', 'Respuesta territorial demasiado grande. Reduce la zona.', 413);
      const chunks = []; let size = 0;
      for await (const chunk of response.body || []) { size += chunk.byteLength; if (size > item.maxBytes) { controller.abort(); error('D_GEO_LIMIT', 'Respuesta territorial demasiado grande. Reduce la zona.', 413); } chunks.push(Buffer.from(chunk)); }
      const raw = Buffer.concat(chunks), declaration = raw.subarray(0, 256).toString('ascii');
      const text = item.format === 'gml' && /encoding=["'](?:ISO-8859-1|windows-1252)["']/i.test(declaration) ? new TextDecoder('windows-1252').decode(raw) : raw.toString('utf8');
      if (!text.trim()) error('D_GEO_EMPTY', 'El proveedor no devolvió datos.', 502);
      if (item.format === 'gml' && /<!DOCTYPE\b|<!ENTITY\b/i.test(text)) error('D_GEO_FORMAT', 'El proveedor devolvió declaraciones XML no admitidas.', 502);
      if (/<(?:\w+:)?(?:ExceptionReport|ServiceExceptionReport|Exception)\b/i.test(text)) error('D_GEO_PROVIDER', 'El proveedor rechazó la consulta territorial. Puede faltar cobertura en esta zona.', 502);
      if (item.format === 'json') {
        let json; try { json = JSON.parse(text); } catch { error('D_GEO_FORMAT', 'El proveedor no devolvió JSON válido.', 502); }
        if (item.operation.startsWith('osm.') && (!Array.isArray(json.elements) || json.elements.length > 4000 || json.remark)) error('D_GEO_LIMIT', 'Consulta OSM incompleta o con demasiados elementos. Reduce la zona.', 413);
      } else if (item.format === 'ascii-grid' && (!/^\s*ncols\s+33\b/i.test(text) || !/^\s*nrows\s+33\b/im.test(text))) error('D_GEO_FORMAT', 'El MDT no devolvió la cuadrícula 33 × 33 esperada.', 502);
      return { ok: true, operation: item.operation, format: item.format, text, source: item.source, cached: false, retrievedAt: new Date(this.now()).toISOString() };
    } catch (e) {
      if (e instanceof BridgeError) throw e;
      if (controller.signal.aborted) error('D_GEO_TIMEOUT', this.closed ? 'Conector territorial cerrado.' : 'El proveedor tardó demasiado. Vuelve a intentarlo.', 504);
      error('D_GEO_NETWORK', 'No se pudo conectar por HTTPS con el proveedor territorial. Comprueba la conexión o inténtalo después.', 502);
    } finally { clearTimeout(timer); }
  }
  dispose() {
    this.closed = true; clearTimeout(this.timer); this.timer = null; this.active?.controller?.abort();
    for (const item of this.queue.splice(0)) { this.inflight.delete(item.key); item.reject(new BridgeError('D_GEO_CLOSED', 'Conector territorial cerrado.', 503)); }
    this.cache.clear(); this.cacheBytes = 0;
  }
}
