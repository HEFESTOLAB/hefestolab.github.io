import test from 'node:test';
import assert from 'node:assert/strict';
import { GeoProxy } from '../geo-proxy.mjs';

const bbox = [-3.6982, 42.3438, -3.6976, 42.3443];

test('territory HTTPS requests identify Dédalo and do not send user credentials', async () => {
  const calls = [];
  const proxy = new GeoProxy({ delay: 0, fetch: async (url, init) => {
    calls.push({ url, init }); return new Response('{"elements":[]}');
  } });
  try {
    await proxy.request({ operation: 'osm.context', bbox });
    assert.equal(calls.length, 1); assert.match(calls[0].init.headers['User-Agent'], /https:\/\/hefestolab.github.io/);
    assert.equal(calls[0].init.headers.Authorization, undefined);
    assert.equal(calls[0].init.redirect, 'error');
  } finally { proxy.dispose(); }
});

test('provider rate limits remain an explicit recoverable error without duplicate queries', async () => {
  let calls = 0;
  const proxy = new GeoProxy({ delay: 0, fetch: async () => { calls++; return new Response('rate limited', { status: 429 }); } });
  try {
    await assert.rejects(proxy.request({ operation: 'osm.trees', bbox }), e => e.code === 'D_GEO_UPSTREAM' && /30 segundos/.test(e.message));
    assert.equal(calls, 1); assert.equal(proxy.cache.size, 0);
  } finally { proxy.dispose(); }
});

test('a provider timeout aborts its fetch and releases the queue for the next layer', async () => {
  let calls = 0, firstSignal;
  const proxy = new GeoProxy({ delay: 0, timeout: 5, fetch: async (url, init) => {
    calls++; if (calls > 1) return new Response('{"elements":[]}');
    firstSignal = init.signal;
    return new Promise((resolve, reject) => init.signal.addEventListener('abort', () => reject(new Error('aborted')), { once: true }));
  } });
  try {
    const first = proxy.request({ operation: 'catastro.parcels', bbox });
    const next = proxy.request({ operation: 'osm.trees', bbox });
    await assert.rejects(first, e => e.code === 'D_GEO_TIMEOUT');
    assert.equal(firstSignal.aborted, true); assert.equal((await next).ok, true); assert.equal(calls, 2);
  } finally { proxy.dispose(); }
});
