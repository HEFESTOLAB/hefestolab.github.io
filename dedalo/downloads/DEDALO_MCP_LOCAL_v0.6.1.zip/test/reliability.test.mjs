import test from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { BrowserBroker, validateExecute } from '../connector.mjs';
import { start } from '../server.mjs';

const origin = 'https://hefestolab.github.io';
const state = { projectId: 'project-tests', revision: 1, name: 'Pagoda', context: [], busy: false };
function paired(options = {}) {
  const broker = new BrowserBroker(options);
  const auth = broker.pair({ code: broker.connection().code, client: { name: 'Tests', version: '0.6.0' }, permissions: { write: true, snapshot: false }, state }, origin);
  return { broker, auth, poll: () => broker.poll({ ...auth, state }, origin), submit: (id, result) => broker.submit({ ...auth, id, result }, origin) };
}
const result = revision => ({ ok: true, projectId: state.projectId, revision, result: { faces: ['face-123'] } });

test('result acknowledgement retry is idempotent and does not enqueue another command', async () => {
  const f = paired();
  try {
    const answer = f.broker.request('execute', { projectId: state.projectId, expectedRevision: 1, command: 'draw.rectangle', params: {} });
    const first = f.poll().request; assert.ok(first);
    assert.equal(f.poll().request, null);
    assert.deepEqual(f.submit(first.id, result(2)), { ok: true });
    assert.equal((await answer).revision, 2);
    assert.deepEqual(f.submit(first.id, result(2)), { ok: true, duplicate: true });
    assert.equal(f.broker.pending.size, 0); assert.equal(f.broker.session.state.revision, 2);
  } finally { f.broker.dispose(); }
});

test('timed out delivered command accepts a late response without disconnecting or rerunning', async () => {
  const f = paired({ writeTimeout: 10 });
  try {
    const answer = f.broker.request('execute', { projectId: state.projectId, expectedRevision: 1, command: 'draw.rectangle', params: {} }).catch(e => e);
    const first = f.poll().request;
    assert.equal((await answer).code, 'D_RESULT_UNKNOWN');
    assert.deepEqual(f.submit(first.id, result(2)), { ok: true, late: true });
    assert.equal(f.broker.session.state.revision, 2); assert.equal(f.broker.connection().paired, true);
    assert.equal(f.poll().request, null);
  } finally { f.broker.dispose(); }
});

test('a slow or backgrounded browser keeps its session beyond the former ten second cutoff', async () => {
  let now = 1000; const f = paired({ now: () => now });
  try {
    now += 65000; assert.equal(f.broker.connection().connected, true);
    const answer = f.broker.request('read', { query: 'status' });
    const first = f.poll().request; f.submit(first.id, result(1)); await answer;
    now += 121000; assert.equal(f.broker.connection().connected, false); assert.equal(f.broker.connection().paired, true);
    await assert.rejects(f.broker.request('read', { query: 'status' }), e => e.code === 'D_BROWSER_DISCONNECTED');
    f.poll(); assert.equal(f.broker.connection().connected, true);
  } finally { f.broker.dispose(); }
});

test('pagination forwards bounded offsets and exact revision; rejects oversized page requests', async () => {
  const f = paired();
  try {
    const payload = { query: 'project', offset: 65536, limit: 32768, expectedRevision: 1 };
    const answer = f.broker.request('read', payload), first = f.poll().request;
    assert.deepEqual(first.payload, payload); f.submit(first.id, result(1)); await answer;
    assert.throws(() => f.broker.request('read', { query: 'project', limit: 10000000 }));
    assert.throws(() => f.submit('never-issued', result(1)), e => e.code === 'D_UNKNOWN_REQUEST');
  } finally { f.broker.dispose(); }
});

test('new section/BIM commands are explicit and readonly/export operations cannot be put in a geometry batch', () => {
  for (const command of ['view.sectionBox', 'view.sectionBoxFit', 'bim.assign', 'bim.categories', 'bim.get', 'bim.clear', 'bim.validate', 'export.ifc']) {
    assert.equal(validateExecute({ projectId: state.projectId, expectedRevision: 1, command, params: {} }).command, command);
  }
  assert.throws(() => validateExecute({ projectId: state.projectId, expectedRevision: 1, command: 'transaction.batch', params: { commands: [{ command: 'export.ifc', params: {} }] } }), e => e.code === 'D_INVALID_BATCH');
});

test('overlapping desktop clients choose different loopback ports instead of failing startup', async () => {
  const port = 48000 + Math.floor(Math.random() * 2000);
  const first = await start({ port, territory: true }); let second;
  try {
    second = await start({ port: first.broker.port, territory: true });
    assert.notEqual(first.broker.port, second.broker.port);
    for (const running of [first, second]) {
      const actual = running.broker.port;
      const response = await fetch('http://127.0.0.1:' + actual + '/v1/status', { method: 'POST', headers: { Origin: 'http://127.0.0.1:' + actual, 'Content-Type': 'application/json' }, body: '{}' });
      assert.equal(response.status, 200); assert.equal((await response.json()).version, '0.6.0');
    }
  } finally { await second?.close(); await first.close(); }
});

test('stdio starts from an unrelated cwd, negotiates MCP, lists tools and bridges live HTTP', async () => {
  const child = spawn(process.execPath, [fileURLToPath(new URL('../server.mjs', import.meta.url)), '--port', String(50500 + Math.floor(Math.random() * 1000))], { cwd: process.env.TEMP || process.cwd(), windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'] });
  let nextId = 0, buffer = '', errors = ''; const waiting = new Map();
  child.stderr.on('data', b => { errors += b; });
  child.stdout.on('data', chunk => {
    buffer += chunk;
    for (;;) {
      const end = buffer.indexOf('\n'); if (end < 0) break;
      const line = buffer.slice(0, end); buffer = buffer.slice(end + 1); if (!line.trim()) continue;
      const message = JSON.parse(line); const pending = waiting.get(message.id);
      if (pending) { waiting.delete(message.id); clearTimeout(pending.timer); message.error ? pending.reject(new Error(JSON.stringify(message.error))) : pending.resolve(message.result); }
    }
  });
  const rpc = (method, params = {}) => new Promise((resolve, reject) => {
    const id = ++nextId, timer = setTimeout(() => { waiting.delete(id); reject(new Error(method + ' timed out: ' + errors)); }, 8000);
    waiting.set(id, { resolve, reject, timer }); child.stdin.write(JSON.stringify({ jsonrpc: '2.0', id, method, params }) + '\n');
  });
  try {
    const init = await rpc('initialize', { protocolVersion: '2025-11-25', capabilities: {}, clientInfo: { name: 'dedalo-live-test', version: '0.6.0' } });
    assert.equal(init.serverInfo.version, '0.6.0'); child.stdin.write(JSON.stringify({ jsonrpc: '2.0', method: 'notifications/initialized' }) + '\n');
    const list = await rpc('tools/list'); assert.deepEqual(list.tools.map(t => t.name).sort(), ['dedalo_connection', 'dedalo_execute', 'dedalo_read']);
    assert.ok(list.tools.find(t => t.name === 'dedalo_read').inputSchema.properties.offset);
    const connection = (await rpc('tools/call', { name: 'dedalo_connection', arguments: {} })).structuredContent;
    assert.equal(connection.paired, false); assert.ok(connection.port >= 1024);
    const post = async (route, body) => {
      const response = await fetch(connection.url + '/v1/' + route, { method: 'POST', headers: { Origin: origin, 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
      assert.equal(response.status, 200); return response.json();
    };
    const auth = await post('pair', { code: connection.code, client: { name: 'Tests', version: '0.6.0' }, permissions: { write: true, snapshot: false }, state });
    const answer = rpc('tools/call', { name: 'dedalo_read', arguments: { query: 'project', offset: 65536, limit: 32768, expectedRevision: 1 } });
    let request; const until = Date.now() + 5000;
    while (!request && Date.now() < until) { request = (await post('poll', { ...auth, state })).request; if (!request) await new Promise(resolve => setTimeout(resolve, 10)); }
    assert.ok(request); assert.equal(request.payload.offset, 65536);
    await post('result', { ...auth, id: request.id, result: result(1) });
    assert.equal((await answer).structuredContent.ok, true);
    assert.equal((await post('result', { ...auth, id: request.id, result: result(1) })).duplicate, true);
    const denied = await rpc('tools/call', { name: 'dedalo_read', arguments: { query: 'snapshot' } }); assert.equal(denied.isError, true);
    await post('disconnect', auth);
  } finally {
    for (const p of waiting.values()) clearTimeout(p.timer);
    child.stdin.end(); if (child.exitCode === null) await new Promise(resolve => { const timer = setTimeout(() => { child.kill(); resolve(); }, 3000); child.once('exit', () => { clearTimeout(timer); resolve(); }); });
  }
});
