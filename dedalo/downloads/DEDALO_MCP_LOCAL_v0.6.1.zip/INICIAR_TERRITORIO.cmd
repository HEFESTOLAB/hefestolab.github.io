@echo off
setlocal
cd /d "%~dp0"
node server.mjs --territory
if errorlevel 1 pause
