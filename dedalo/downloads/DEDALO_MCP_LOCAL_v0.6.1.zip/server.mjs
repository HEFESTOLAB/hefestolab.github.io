#!/usr/bin/env node
import { createServer } from 'node:http';
import { fileURLToPath } from 'node:url';
import { resolve } from 'node:path';
import { serveStdio, StdioServerTransport } from '@modelcontextprotocol/server/stdio';
import { BrowserBroker, createMcpServer, DEFAULT_PORT } from './connector.mjs';
import { httpHandler } from './http.mjs';
import { GeoProxy } from './geo-proxy.mjs';
import * as tls from 'node:tls';

// Honour the operating system trust store when the bundled Node runtime supports
// it. Certificate verification stays enabled (including corporate trusted CAs).
export function configureSystemTrust() {
  if (typeof tls.getCACertificates === 'function' && typeof tls.setDefaultCACertificates === 'function') {
    tls.setDefaultCACertificates([...new Set([...tls.getCACertificates('default'), ...tls.getCACertificates('system')])]);
  }
}

export function parseOptions(args) {
  const options = { port: DEFAULT_PORT, origins: [] };
  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--port') { const port = Number(args[++i]); if (!Number.isInteger(port) || port < 1024 || port > 65535) throw new Error('Puerto no válido.'); options.port = port; }
    else if (args[i] === '--allow-origin') { const origin = args[++i]; if (!origin || origin === '*' || origin === 'null') throw new Error('Usa un origen HTTP(S) exacto.'); options.origins.push(origin); }
    else if (args[i] === '--no-file-origin') options.allowFileOrigin = false;
    else if (args[i] === '--territory') options.territory = true;
    else if (args[i] === '--strict-port') options.strictPort = true;
    else throw new Error('Opción desconocida: ' + args[i]);
  }
  return options;
}
export async function start(options = {}) {
  configureSystemTrust();
  options = { port: DEFAULT_PORT, ...options };
  const broker = new BrowserBroker(options), geoProxy = new GeoProxy(); let http;
  // Desktop clients may overlap during restart, and Claude and Codex can both be
  // open. Each process keeps its own authenticated broker on an available port.
  for (let attempt = 0; attempt < (options.strictPort ? 1 : 20); attempt++) {
    const port = options.port + attempt; if (port > 65535) break;
    const candidate = createServer(httpHandler(broker, { ...options, port, geoProxy }));
    candidate.requestTimeout = 30000; candidate.headersTimeout = 10000; candidate.maxConnections = 32;
    try {
      await new Promise((accept, reject) => {
        const failed = error => { candidate.removeListener('listening', ready); reject(error); };
        const ready = () => { candidate.removeListener('error', failed); accept(); };
        candidate.once('error', failed); candidate.once('listening', ready); candidate.listen(port, '127.0.0.1');
      });
      broker.port = port; http = candidate; break;
    } catch (error) { candidate.close(); if (error.code !== 'EADDRINUSE' || options.strictPort) throw error; }
  }
  if (!http) { broker.dispose(); geoProxy.dispose(); throw new Error('No hay un puerto local libre. Cierra conectores antiguos o elige otro puerto.'); }
  const transport = options.territory ? null : new StdioServerTransport(process.stdin, process.stdout, { maxBufferSize: 1024 * 1024 });
  const handle = transport ? serveStdio(() => createMcpServer(broker), { transport, onerror: error => console.error('DÉDALO MCP:', error.message) }) : null;
  let closing = false;
  const close = async () => { if (closing) return; closing = true; broker.dispose(); geoProxy.dispose(); http.closeAllConnections(); http.close(); await handle?.close(); };
  if (handle) process.stdin.once('end', close); process.once('SIGINT', close); process.once('SIGTERM', close);
  console.error('DÉDALO local en http://127.0.0.1:' + broker.port + '/dedalo/?seguro&conector=1' + (handle ? '. Pide dedalo_connection a tu IA para emparejar.' : '. Territorio disponible sin cliente IA. Cierra con Ctrl+C.'));
  if (handle && process.stdin.readableEnded) await close();
  return { broker, close, http };
}
if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  start(parseOptions(process.argv.slice(2))).catch(error => { console.error('No se pudo iniciar DÉDALO MCP:', error.message); process.exitCode = 1; });
}
