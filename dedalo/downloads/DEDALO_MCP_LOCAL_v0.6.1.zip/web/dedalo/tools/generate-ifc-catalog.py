"""Regenerate bundled IFC schema catalog from IfcOpenShell official EXPRESS definitions.
Requires ifcopenshell (development/validation only); browser export has no dependency.
"""
import sys,json,pathlib
try: import ifcopenshell
except ImportError:
 sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[3]/'ifc-python'))
 import ifcopenshell

def attrs(d):
 result=[]
 for a in d.all_attributes():
  t=str(a.type_of_attribute()); row={'name':a.name(),'optional':a.optional(),'type':t}
  if t.startswith('<enumeration '): row['enum']=t.split(': (')[1].split(')>')[0].split(', ')
  result.append(row)
 return result

def descendant(d,name):
 while d:
  if d.name()==name:return True
  d=d.supertype()
 return False
catalog={}
for schema in ['IFC2X3','IFC4']:
 s=ifcopenshell.schema_by_name(schema); data={}
 for d in s.declarations():
  if not hasattr(d,'supertype') or d.is_abstract() or not (descendant(d,'IfcElement') or d.name()=='IfcSpace'):continue
  row={'entity':d.name(),'attributes':attrs(d),'family':'architecture'}
  if descendant(d,'IfcDistributionElement'):row['family']='MEP'
  elif descendant(d,'IfcElementComponent') or d.name() in ['IfcBeam','IfcColumn','IfcMember','IfcFooting','IfcPile']:row['family']='structure'
  enums=next((a['enum'] for a in row['attributes'] if a['name']=='PredefinedType'),[])
  row['predefinedTypes']=enums
  for type_name in [d.name()+'Type',d.name()+'Style']:
   try: td=s.declaration_by_name(type_name)
   except:continue
   if hasattr(td,'supertype') and not td.is_abstract() and descendant(td,'IfcTypeProduct'):
    row['type']={'entity':type_name,'attributes':attrs(td)}
    if not enums: row['predefinedTypes']=next((a['enum'] for a in row['type']['attributes'] if a['name']=='PredefinedType'),[])
    break
  data[d.name()]=row
 catalog[schema]=data
# In IFC2X3 MEP classification usually lives on types rather than occurrences.
for name,row in catalog['IFC4'].items():
 if name in catalog['IFC2X3']:continue
 try: td=ifcopenshell.schema_by_name('IFC2X3').declaration_by_name(name+'Type')
 except:continue
 if not hasattr(td,'supertype') or td.is_abstract():continue
 d=ifcopenshell.schema_by_name('IFC4').declaration_by_name(name).supertype()
 while d and d.name() not in catalog['IFC2X3']:d=d.supertype()
 if not d:continue
 target=catalog['IFC2X3'][d.name()]
 catalog['IFC2X3'][name]={'entity':name,'exportEntity':d.name(),'attributes':target['attributes'],'family':row['family'],'type':{'entity':name+'Type','attributes':attrs(td)},'predefinedTypes':next((a['enum'] for a in attrs(td) if a['name']=='PredefinedType'),[])}
path=pathlib.Path(__file__).resolve().parents[1]/'app/js/core/ifc-categories.js'
header='''/* Dédalo IFC catalog. Generated from IfcOpenShell 0.9.0.post1 IFC2X3 TC1 / IFC4 ADD2 TC1 schemas.
 * Regenerate: python tools/generate-ifc-catalog.py. The runtime exporter is original Dédalo code.
 * IFC schema documentation: https://standards.buildingsmart.org/IFC/RELEASE/IFC4/ADD2_TC1/HTML/
 */
(function(root){'use strict'; const D=root.DEDALO;
const DATA='''
path.write_text(header+json.dumps(catalog,ensure_ascii=True,separators=(',',':'))+';\n'+'''const clone = x => JSON.parse(JSON.stringify(x));
function schema(value) { const s=String(value||'IFC4').toUpperCase(); if(!DATA[s]) throw new Error('Esquema IFC no admitido: '+s); return s; }
function list(value) { return Object.values(DATA[schema(value)]).map(x=>({entity:x.entity,exportEntity:x.exportEntity||x.entity,predefinedTypes:x.predefinedTypes.slice(),family:x.family,requiredAttributes:x.attributes.slice(8).filter(a=>!a.optional&&!a.enum).map(a=>a.name),type:x.type?x.type.entity:null})).sort((a,b)=>a.entity.localeCompare(b.entity)); }
function resolve(value,version) { const s=schema(version), entity=typeof value==='string'?value:value&&value.entity; const row=DATA[s][entity]; return row?clone(row):null; }
D.IFCCategories={schema,list,resolve,schemas:['IFC4','IFC2X3'],source:'IfcOpenShell 0.9.0.post1 official IFC2X3/IFC4 schemas'};
})(typeof window!=='undefined'?window:globalThis);
''',encoding='utf-8')
print({s:len(c) for s,c in catalog.items()},path.stat().st_size)

